<template>
	<view>
		<!-- 自定义状态栏 -->
		<view class="status_title">
			<image class="status_left" src="../../static/icon/back.png" mode="widthFix" @click="back()"></image>
			<view class="status_center">人脸识别考勤系统</view>
		</view>
		
		<view class="tn-padding-bottom-lg">
		  <view class="tn-flex tn-flex-row-between">
		    <view class="justify-content-item tn-margin tn-text-bold tn-text-xxl">
		      学生查看
		    </view>
		  </view>
		  
		  <view class="tn-flex tn-margin-left tn-margin-right tn-margin-top-sm">
			<view class="tn-padding-left-sm" style="width: 100%;">
			  <view class="tn-flex tn-flex-row-between tn-flex-col-between">
			    <view class="justify-content-item">
			      <text class="tn-color-cat tn-text-lg tn-text-bold">
				  签到学生如下：</text>
			    </view>
			  </view>
			</view>
			</view>
		  </view>
		  
		  <view class="box">
		  		<view class="line"></view>
				<view class="about-shadow tn-margin-top-lg tn-padding-top-sm tn-padding-bottom-sm">
				  <view class="student" v-for="(item,index) in students" :key="index">
				  	<tn-list-cell :hover="true" :unlined="true" :radius="true" :fontSize="30">
				  	  <view class="tn-flex tn-flex-col-center">
				  	    <text style="flex: 1;">{{item.name}}</text>
						<text style="flex: 2;">{{item.status}}</text>
				  	  </view>
				  	</tn-list-cell>
				  </view>
				</view>
		  </view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				name:{
					class_name:"", // 班级名称
				},
				students:[{
					name:'高心雨',
					status:'已签'
				},{
					name:'秦阳',
					status:'已签'
				},{
					name:'123',
					status:'未签'
				}]	// 学生姓名 从后端获取
			};
		},
		
		methods:{
			// 返回上一级
			back(){
				// uni.navigateTo({
				// 	url:'/pages/class/class',
				// });
				uni.navigateBack({
					delta: 1
				})
			},
		}
	}
</script>

<style lang="scss">
/* 自定义导航栏 */
.status_title {
	box-sizing: border-box;
	display: flex;
	justify-content: space-between;
	align-items: center;
	width: 100%;
	height: 44px;
	padding: 16px;
	background-color: #fafafa;
	
	.status_left {
		width: 18px;
	}
	.status_center {
		font-size: 17px;
		font-weight: 700;
	}
}

// 内容
.box{
	  text-align: center;
	  .line{
	  	    width: 50%;
	  	    height: 1px;
	  	    border-top: solid #ACC0D8 5rpx;
	  		margin-top: 20rpx;
			margin-left: 25%;
	  }
}

/* 页面 start*/
  .about-shadow {
    border-radius: 15rpx;
    box-shadow: 0rpx 0rpx 50rpx 0rpx rgba(0, 0, 0, 0.07);
	width: 650rpx;
	margin-left: 7%;
  }

  /* 页面 end*/
</style>
