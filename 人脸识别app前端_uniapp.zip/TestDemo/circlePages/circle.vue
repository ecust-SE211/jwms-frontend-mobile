<template>
	<view class="template-edit tn-safe-area-inset-bottom">
    <!-- 顶部自定义导航 -->
    <tn-nav-bar fixed alpha customBack>
      <view slot="back" class='tn-custom-nav-bar__back'
        @click="goBack">
        <text class='icon tn-icon-left'></text>
        <text class='icon tn-icon-home-capsule-fill'></text>
      </view>
    </tn-nav-bar>
		
   <!-- <view class="tn-safe-area-inset-bottom" :style="{paddingTop: vuex_custom_bar_height + 'px'}">
      
      <view class="tn-flex tn-flex-row-between tn-flex-col-center tn-padding-top tn-margin">
        <view class="tn-flex justify-content-item">
          <view class="tn-bg-black tn-color-white tn-text-center" style="border-radius: 100rpx;margin-right: 8rpx;width: 45rpx;height: 45rpx;line-height: 45rpx;">
            <text class="tn-icon-topics" style="font-size: 30rpx;"></text>
          </view>
          <view class="tn-text-lg tn-padding-right-xs tn-text-bold">想说点什么</view>
        </view>
        <view class="justify-content-item tn-text-df tn-color-grey">
          <text class="tn-padding-xs">500字内</text>
          <text class="tn-icon-keyboard-circle"></text>
        </view>
      </view> -->
      
      
      <!-- <view class="tn-margin tn-bg-gray--light tn-padding" style="border-radius: 10rpx;">
        <textarea maxlength="500" placeholder="说点什么 , 万一火了呢"
          placeholder-style="color:#AAAAAA"></textarea>
      </view> -->
      
      <!-- <view class="tn-flex tn-flex-row-between tn-flex-col-center tn-padding-top-xl tn-margin">
        <view class="tn-flex justify-content-item">
          <view class="tn-bg-black tn-color-white tn-text-center" style="border-radius: 100rpx;margin-right: 8rpx;width: 45rpx;height: 45rpx;line-height: 45rpx;">
            <text class="tn-icon-image" style="font-size: 30rpx;"></text>
          </view>
          <view class="tn-text-lg tn-padding-right-xs tn-text-bold">发点什么图咧</view>
        </view>
        <view class="justify-content-item tn-text-df tn-color-grey" @tap="clear">
          <text class="tn-padding-xs">清空上传</text>
          <text class="tn-icon-delete"></text>
        </view>
      </view>
      
      
      
      
      <view class="tn-margin-left tn-padding-top-xs">
        <tn-image-upload-drag
          ref="imageUpload"
          :action="action"
          :width="236"
          :height="236"
          :formData="formData"
          :fileList="fileList"
          :disabled="disabled"
          :autoUpload="autoUpload"
          :maxCount="maxCount"
          :showUploadList="showUploadList"
          :showProgress="showProgress"
          :deleteable="deleteable"
          :customBtn="customBtn"
          @sort-list="onSortList"
        />

      </view>
      -->
      <!-- <view class="tn-flex tn-flex-row-between tn-flex-col-center tn-padding-top-xl tn-margin">
        <view class="tn-flex justify-content-item">
          <view class="tn-bg-black tn-color-white tn-text-center" style="border-radius: 100rpx;margin-right: 8rpx;width: 45rpx;height: 45rpx;line-height: 45rpx;">
            <text class="tn-icon-tag" style="font-size: 30rpx;"></text>
          </view>
          <view class="tn-text-lg tn-padding-right-xs tn-text-bold">话题标签</view>
        </view>
        <view class="justify-content-item tn-text-df tn-color-grey">
          <text class="tn-padding-xs">选择</text>
          <text class="tn-icon-right"></text>
        </view>
      </view>
      
      <view class="tn-tag-content tn-margin tn-text-justify tn-padding-bottom">
        <view v-for="(item, index) in tagList" :key="index" class="tn-tag-content__item tn-margin-right tn-round tn-text-sm tn-text-bold" :class="[`tn-bg-${item.color}--light tn-color-${item.color}`]">
          <text class="tn-tag-content__item--prefix">#</text> {{ item.title }}
        </view>
      </view>  
      

      <view class="tn-flex tn-footerfixed">
        <view class="tn-flex-1 justify-content-item tn-margin-sm tn-text-center">
          <tn-button backgroundColor="#3668FC" padding="40rpx 0" width="60%" shadow fontBold @tap="upload">
       
            <text class="tn-color-white">晒帖子</text>
            
          </tn-button>
        </view>
      </view>
      
    </view>
    -->
	<view class=""  >
	  <view class="" style="padding-top: 100rpx;width: 100%;">
	    <view class="tn-flex tn-flex-col-top tn-margin tn-cat-shadow tn-padding">
	      <view class="">
	        <view class="icon15__item--icon tn-flex tn-flex-row-center tn-flex-col-center tn-shadow-blur" style="background-color: #F3F2F7;color: #7C8191;">
	          <view class="tn-icon-notice"></view>
	        </view>
	      </view>
	      <view class="tn-padding-left-sm" style="width: 100%;">
	        <view class="tn-flex tn-flex-row-between tn-flex-col-between">
	          <view class="justify-content-item">
	            <text class="tn-color-cat tn-text-lg tn-text-bold">进行中</text>
	          </view>
	          <!-- <view class="justify-content-item tag">
	            官 方
	          </view> -->
	        </view>
	        <view class=" tn-padding-top-xs  tn-text-ellipsis-2">
	          <text class="tn-color-gray">软件212</text>
	        </view>
	        <view class="tn-flex tn-flex-row-between tn-flex-col-between tn-margin-top-sm">
	          <!-- <view class="justify-content-item tn-round tn-text-xs tn-bg-orangered--light tn-color-orangered" style="padding: 5rpx 15rpx;">
	            <text class="tn-padding-right-xs">#</text> 公 告
	          </view> -->
	          <view class="justify-content-item tn-color-gray tn-text-center tn-color-gray">
	            <text class="tn-icon-time tn-padding-right-xs tn-text-df"></text>
	            <text class="tn-text-sm">2024-1-10 16:27</text>
	          </view>
	        </view>
	      </view>
	    </view>
	  </view>
	</view>
	<view class=""  >
	  <view class="" style="padding-top: 0rpx;width: 100%;">
	    <view class="tn-flex tn-flex-col-top tn-margin tn-cat-shadow tn-padding">
	      <view class="">
	        <view class="icon15__item--icon tn-flex tn-flex-row-center tn-flex-col-center tn-shadow-blur" style="background-color: #F3F2F7;color: #7C8191;">
	          <view class="tn-icon-notice"></view>
	        </view>
	      </view>
	      <view class="tn-padding-left-sm" style="width: 100%;">
	        <view class="tn-flex tn-flex-row-between tn-flex-col-between">
	          <view class="justify-content-item">
	            <text class="tn-color-cat tn-text-lg tn-text-bold">已完成</text>
	          </view>
	          <!-- <view class="justify-content-item tag">
	            官 方
	          </view> -->
	        </view>
	        <view class=" tn-padding-top-xs  tn-text-ellipsis-2">
	          <text class="tn-color-gray">软件212</text>
	        </view>
	        <view class="tn-flex tn-flex-row-between tn-flex-col-between tn-margin-top-sm">
	          <!-- <view class="justify-content-item tn-round tn-text-xs tn-bg-orangered--light tn-color-orangered" style="padding: 5rpx 15rpx;">
	            <text class="tn-padding-right-xs">#</text> 公 告
	          </view> -->
	          <view class="justify-content-item tn-color-gray tn-text-center tn-color-gray">
	            <text class="tn-icon-time tn-padding-right-xs tn-text-df"></text>
	            <text class="tn-text-sm">2024-1-8 8:30</text>
	          </view>
	        </view>
	      </view>
	    </view>
	  </view>
	</view>
    <view class='tn-tabbar-height'></view>
    
	</view>
</template>

<script>
  import template_page_mixin from '@/libs/mixin/template_page_mixin.js'
	export default {
    name: 'TemplateEdit',
    mixins: [template_page_mixin],
		data() {
			return {
        tagList: [
          {
            color: 'red',
            title: "元神",
          },
          {
            color: 'cyan',
            title: "LOL",
          },
          {
            color: 'blue',
            title: "图鸟",
          },
          {
            color: 'green',
            title: "科技",
          },
          {
            color: 'orange',
            title: "免费",
          },
          {
            color: 'purplered',
            title: "前端",
          },
          {
            color: 'purple',
            title: "后端",
          },
          {
            color: 'brown',
            title: "UI设计",
          },
          {
            color: 'yellowgreen',
            title: "求助",
          },
          {
            color: 'grey',
            title: "吃货",
          },
          {
            color: 'orangered',
            title: "萌宠",
          }
        ],
				action: 'https://www.hualigs.cn/api/upload',
				// action: '',
				formData: {
				  apiType: 'this,ali',
				  token: 'dffc1e06e636cff0fdf7d877b6ae6a2e',
				  image: null
				},
				fileList: [{url: 'https://cdn.nlark.com/yuque/0/2022/jpeg/280373/1663227510540-assets/web-upload/2403ceb1-0266-4536-80ca-bcaf0e3934ed.jpeg'}, {url: 'https://cdn.nlark.com/yuque/0/2022/jpeg/280373/1663227253078-assets/web-upload/45864702-0a10-476d-8d40-bdd87e9239c7.jpeg'}, {url: 'https://cdn.nlark.com/yuque/0/2022/jpeg/280373/1663227253918-assets/web-upload/5828cea1-30b1-499a-a570-35c8f2b4d5b5.jpeg'}, {url: 'https://cdn.nlark.com/yuque/0/2022/jpeg/280373/1663228732454-assets/web-upload/1fc5a117-3326-481e-bb38-7f7839a3fb1e.jpeg'}],
				showUploadList: true,
				customBtn: false,
				autoUpload: true,
				showProgress: false,
				deleteable: true,
				customStyle: false,
				maxCount: 9,
				disabled: false,
			}
		},
		onLoad() {

		},
		methods: {
      // 跳转
      tn(e) {
      	uni.navigateTo({
      		url: e,
      	});
      },
      // 手动上传文件
      upload() {
        this.$refs.imageUpload.upload()
      },
      // 手动清空列表
      clear() {
        this.$refs.imageUpload.clear()
      },
      // 图片拖拽重新排序
      onSortList(list) {
        console.log(list);
      },
		}
	}
</script>

<style lang="scss" scoped>
	.template-edit{
	}
  
  /* 胶囊*/
  .tn-custom-nav-bar__back {
    width: 100%;
    height: 100%;
    position: relative;
    display: flex;
    justify-content: space-evenly;
    align-items: center;
    box-sizing: border-box;
    background-color: rgba(0, 0, 0, 0.15);
    border-radius: 1000rpx;
    border: 1rpx solid rgba(255, 255, 255, 0.5);
    color: #FFFFFF;
    font-size: 18px;
    
    .icon {
      display: block;
      flex: 1;
      margin: auto;
      text-align: center;
    }
    
    &:before {
      content: " ";
      width: 1rpx;
      height: 110%;
      position: absolute;
      top: 22.5%;
      left: 0;
      right: 0;
      margin: auto;
      transform: scale(0.5);
      transform-origin: 0 0;
      pointer-events: none;
      box-sizing: border-box;
      opacity: 0.7;
      background-color: #FFFFFF;
    }
  }
  
  /* 底部悬浮按钮 start*/
  .tn-tabbar-height {
  	min-height: 100rpx;
  	height: calc(120rpx + env(safe-area-inset-bottom) / 2);
  }
  .tn-footerfixed {
    position: fixed;
    width: 100%;
    bottom: calc(30rpx + env(safe-area-inset-bottom));
    z-index: 1024;
    box-shadow: 0 1rpx 6rpx rgba(0, 0, 0, 0);
    
  }
  /* 底部悬浮按钮 end*/
  
  /* 标签内容 start*/
  .tn-tag-content {
    &__item {
      display: inline-block;
      line-height: 45rpx;
      padding: 10rpx 30rpx;
      margin: 20rpx 20rpx 5rpx 0rpx;
      
      &--prefix {
        padding-right: 10rpx;
      }  
    }
  }
  /* 标签内容 end*/
  /* 页面阴影 start*/
  .tn-cat-shadow {
    border-radius: 15rpx;
    box-shadow: 0rpx 0rpx 50rpx 0rpx rgba(0, 0, 0, 0.07);
  }
</style>
